import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, TextInput, Alert } from 'react-native';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { format } from 'date-fns';

const questions = [
  "medytowałeś?",
  "jadłeś zdrowe?",
  "był stres?",
  "dużo wody?",
  "trening?",
  "min 6k króków?",
  "min 7h snu?",
  "dobry sen?",
  "dużo bliskich?",
  "alkochol?",
  "byłeś w robocie?",
  "thc?",
  "keks?",
  "zrobiłeś produktywne?",
  "granie?",
  "sytuacja niestandardowa która miała wpływ na samopoczucie?",
];

export default function App() {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState(Array(questions.length).fill(0));
  const [mood, setMood] = useState(3);
  const [notes, setNotes] = useState('');
  const [showMoodScreen, setShowMoodScreen] = useState(false);
  const [showNotesScreen, setShowNotesScreen] = useState(false);

  const handleAnswer = (answer) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestionIndex] = answer;
    setAnswers(newAnswers);

    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      setShowMoodScreen(true);
    }
  };

  const handleMoodSelect = (selectedMood) => {
    setMood(selectedMood);
    setShowMoodScreen(false);
    setShowNotesScreen(true);
  };

  const saveDataAutomatically = async () => {
  const today = format(new Date(), 'yyyy-MM-dd HH:mm:ss');
  const csvRow = [
    today.split(' ')[0], // Tylko data bez godziny
    ...answers,
    mood,
    `"${notes.replace(/"/g, '""')}"`
  ].join(',');

  const fileName = 'wellness_data.csv';
  const fileUri = `${FileSystem.documentDirectory}${fileName}`;

  try {
    const fileInfo = await FileSystem.getInfoAsync(fileUri);
    let fileContent = '';

    if (fileInfo.exists) {
      fileContent = await FileSystem.readAsStringAsync(fileUri, { encoding: FileSystem.EncodingType.UTF8 });
    } else {
      // Jeśli plik nie istnieje, dodaj nagłówek
      const csvHeader = [
        'date',
        ...questions.map((_, i) => `q${i+1}`),
        'mood',
        'notes'
      ].join(',');
      fileContent = csvHeader + '\n';
    }

    // Dopisujemy nową linię i zapisujemy cały plik na nowo
    fileContent += csvRow + '\n';
    await FileSystem.writeAsStringAsync(fileUri, fileContent, { encoding: FileSystem.EncodingType.UTF8 });

    Alert.alert('Sukces', 'Dodano nowy wpis do dziennika!');
    resetQuestionnaire();
  } catch (error) {
    Alert.alert('Błąd', 'Wystąpił problem przy zapisie: ' + error.message);
  }
};


  const resetQuestionnaire = () => {
    setCurrentQuestionIndex(0);
    setAnswers(Array(questions.length).fill(0));
    setMood(3);
    setNotes('');
    setShowMoodScreen(false);
    setShowNotesScreen(false);
  };

  const downloadFile = async () => {
    const fileName = 'wellness_data.csv';
    const fileUri = `${FileSystem.documentDirectory}${fileName}`;
    
    try {
      const fileInfo = await FileSystem.getInfoAsync(fileUri);
      if (!fileInfo.exists) {
        Alert.alert('Błąd', 'Brak danych do pobrania!');
        return;
      }
      
      await Sharing.shareAsync(fileUri, {
        mimeType: 'text/csv',
        dialogTitle: 'Udostępnij dziennik wellness',
        UTI: 'public.comma-separated-values-text'
      });
    } catch (error) {
      Alert.alert('Błąd', 'Wystąpił problem: ' + error.message);
    }
  };

  if (showNotesScreen) {
    return (
      <View style={styles.container}>
        <Text style={styles.header}>Dodatkowe notatki</Text>
        
        <TextInput
          style={styles.notesInput}
          multiline
          placeholder="Wpisz swoje dodatkowe uwagi..."
          placeholderTextColor="#888"
          value={notes}
          onChangeText={setNotes}
          onSubmitEditing={saveDataAutomatically} // Zapisz po zatwierdzeniu klawiatury
        />
        
        <View style={styles.buttonGroup}>
          <TouchableOpacity 
            style={[styles.button, styles.saveButton]} 
            onPress={saveDataAutomatically} // Ręczne zapisanie jeśli nie użyto klawiatury
          >
            <Text style={styles.buttonText}>Zakończ i zapisz</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={[styles.button, styles.downloadButton]} onPress={downloadFile}>
            <Text style={styles.buttonText}>Pobierz plik CSV</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  if (showMoodScreen) {
    return (
      <View style={styles.container}>
        <Text style={styles.header}>Jak oceniasz swoje samopoczucie?</Text>
        
        <View style={styles.moodButtons}>
          {[1, 2, 3, 4, 5].map((num) => (
            <TouchableOpacity
              key={num}
              style={[
                styles.moodButton,
                mood === num && styles.selectedMoodButton
              ]}
              onPress={() => handleMoodSelect(num)}
            >
              <Text style={styles.moodButtonText}>{num}</Text>
            </TouchableOpacity>
          ))}
        </View>
        
        <Text style={styles.moodDescription}>
          {mood === 1 ? 'Bardzo źle' : 
           mood === 2 ? 'Źle' : 
           mood === 3 ? 'Neutralnie' : 
           mood === 4 ? 'Dobrze' : 'Znakomicie'}
        </Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.progressText}>Pytanie {currentQuestionIndex + 1}/{questions.length}</Text>
      <Text style={styles.question}>{questions[currentQuestionIndex]}</Text>
      
      <View style={styles.answerButtons}>
        <TouchableOpacity 
          style={[styles.button, styles.yesButton]}
          onPress={() => handleAnswer(1)}
        >
          <Text style={styles.buttonText}>Tak</Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={[styles.button, styles.noButton]}
          onPress={() => handleAnswer(0)}
        >
          <Text style={styles.buttonText}>Nie</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#121212',
    justifyContent: 'center',
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 30,
    color: '#E0E0E0',
    textAlign: 'center',
  },
  question: {
    fontSize: 20,
    marginBottom: 40,
    textAlign: 'center',
    color: '#EEEEEE',
    lineHeight: 28,
  },
  progressText: {
    fontSize: 16,
    color: '#9E9E9E',
    textAlign: 'center',
    marginBottom: 10,
  },
  answerButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 20,
  },
  buttonGroup: {
    marginTop: 20,
  },
  button: {
    padding: 18,
    borderRadius: 10,
    marginBottom: 15,
    alignItems: 'center',
    elevation: 3,
  },
  yesButton: {
    backgroundColor: '#2E7D32',
    width: '45%',
  },
  noButton: {
    backgroundColor: '#C62828',
    width: '45%',
  },
  saveButton: {
    backgroundColor: '#1565C0',
  },
  downloadButton: {
    backgroundColor: '#37474F',
  },
  moodButtons: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginVertical: 30,
  },
  moodButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#424242',
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedMoodButton: {
    backgroundColor: '#1976D2',
  },
  moodButtonText: {
    fontSize: 20,
    color: '#FAFAFA',
    fontWeight: 'bold',
  },
  moodDescription: {
    fontSize: 18,
    textAlign: 'center',
    color: '#BDBDBD',
    marginTop: 10,
  },
  notesInput: {
    backgroundColor: '#1E1E1E',
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
    minHeight: 150,
    borderWidth: 1,
    borderColor: '#333',
    textAlignVertical: 'top',
    color: '#E0E0E0',
    fontSize: 16,
  },
});
